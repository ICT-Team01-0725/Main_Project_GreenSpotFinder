// 관리자 메인
function admin_getAdminGo() {
	location.href = "/admin/index";
}

// 공지사항 리스트
function admin_notice_list(cPage) {
	location.href = `/admin/noticelist?cPage=${cPage || 1}`;
}

function admin_notice_detail(n_idx) {
	location.href = "/admin/noticedetail?n_idx="+n_idx;
}

// 공지사항 글쓰기
function admin_notice_write() {
	location.href = "/admin/noticeinsertgo";
}

function admin_notice_write_ok(f) {
	f.action = "/admin/noticeinsert";
	f.submit();
}

function moveToPage(cPage, cmd) {
	cPage = parseInt(cPage);
	window.location.href = `${cmd}?cPage=${cPage}`;
}


function admin_notice_down(f_name) {
	location.href = "/notice_down?f_name=" + f_name;
}

// 공지사항 수정하기
function admin_notice_update(f) {
	f.action = "/admin/noticeupdatego";
	f.submit();
}

function admin_notice_update_ok(f) {
	f.action = "/admin/noticeupdate";
	f.submit();
}

function admin_notice_delete_ok(f) {
	f.action = "/admin/noticedelete";
	f.submit();
}

// 1:1 문의 리스트
function admin_qna_list(cPage) {
	location.href = `/admin/qnalist?cPage=${cPage || 1}`;
}

function admin_qna_detail(q_idx) {
	location.href = "/admin/qnadetail?q_idx="+q_idx;
}

// 1:1 문의 글쓰기
function admin_qna_write() {
	location.href = "/admin/qnainsert";
}

function admin_qna_write_ok(f) {
	f.action = "/admin/qnainsertok";
	f.submit();
}


function admin_qna_down(f_name) {
	location.href = "/qna_down?f_name=" + f_name;
}

// 1:1 문의 수정하기
function admin_qna_update(f) {
	f.action = "/admin/qnaupdatego";
	f.submit();
}

function admin_qna_update_ok(f) {
	f.action = "/admin/qnaupdate";
	f.submit();
}


// 고객의 소리
function admin_inquery_list(cPage) {
	location.href = `/admin/inquerylist?cPage=${cPage||1}`;
}

function admin_inquery_detail(i_idx) {
	location.href = `/admin/inquerydetail?i_idx=${i_idx}`;
}


function admin_inquery_write_ok(f) {
	f.action = "/inquery/insert";
	f.submit();
}


function admin_inquery_down(f_name) {
	location.href = "/inquery_down?f_name=" + f_name;
}

// 고객의 소리 수정하기
function admin_inquery_update(f) {
	f.action = "/inquery/update";
	f.submit();
}

function admin_inquery_update_ok(f) {
	f.action = "/inquery/updateok";
	f.submit();
}

// 고객의 소리 삭제하기
function admin_inquery_delete(f) {
	f.action = "/inquery/delete";
	f.submit();
}

function admin_inquery_delete_ok(f) {
	f.action = "/inquery/deleteok";
	f.submit();
}

// 자주하는 질문 리스트
function admin_fna_list(cPage) {
	location.href = `/admin/fnalist?cPage=${cPage || 1}`;
}

function admin_fna_detail(f_idx) {
	location.href = "/admin/fnadetail?f_idx=${f_idx}";
}

// 자주하는 질문 글쓰기
function admin_fna_write() {
	location.href = "/admin/fnainsert";
}

function admin_fna_write_ok(f) {
	f.action = "/admin/fnainsertok";
	f.submit();
}


// 자주하는 질문 수정하기
function admin_fna_update(f) {
	f.action = "/admin/fnaupdate";
	f.submit();
}

function admin_fna_update_ok(f) {
	f.action = "/admin/fnaupdateok";
	f.submit();
}

// 회원관리 리스트
function admin_user_list(cPage) {
	location.href = `/admin/userlist?cPage=${cPage || 1}`;
}

function admin_user_detail(u_id) {
	location.href = `/admin/userdetail?u_id=${u_id}`;
}

// 회원관리 글쓰기
function admin_user_write() {
	location.href = "/admin/userinsert";
}

function admin_user_write_ok(f) {
	f.action = "/admin/userinsertok";
	f.submit();
}


function admin_user_down(f_name) {
	location.href = "/admin/user_down?f_name=" + f_name;
}

// 회원관리 수정하기
function admin_user_update(f) {
	f.action = "/admin/userupdate";
	f.submit();
}

function admin_user_update_ok(f) {
	f.action = "/admin/userupdateok";
	f.submit();
}


// 회원관리 삭제하기
function admin_user_delete(f) {
	f.action = "/admin/userdelete";
	f.submit();
}

function admin_user_delete_ok(f) {
	f.action = "/admin/userdeleteok";
	f.submit();
}

// 관리자 리스트
function admin_list(cPage) {
	location.href = `/admin/adminlist?cPage=${cPage}`;
}

function admin_detail() {
	location.href = "/admin/admindetail";
}

// 관리자 글쓰기
function admin_write() {
	location.href = "/admin/admininsert";
}

function admin_write_ok(f) {
	f.action = "/admin/admininsertok";
	f.submit();
}


function admin_down(f_name) {
	location.href = "/admin/admin_down?f_name=" + f_name;
}

// 관리자 수정하기
function admin_update(f) {
	f.action = "/admin/adminupdatego";
	f.submit();
}

function admin_update_ok(f) {
	f.action = "/admin/adminupdate";
	f.submit();
}


// 관리자 삭제하기
function admin_delete(f) {
	f.action = "/admin/admindelete";
	f.submit();
}

function admin_delete_ok(f) {
	f.action = "/admin/admindeleteok";
	f.submit();
}



// 녹지 행사 관리
function admin_event_list() {
	location.href = "/ev/list";
}

function admin_event_detail() {
	location.href = "/ev/detail";
}

// 녹지 행사 관리 글쓰기
function admin_event_write() {
	location.href = "/ev/insert";
}

function admin_event_write_ok(f) {
	f.action = "/ev/insertok";
	f.submit();
}


function admin_event_down(f_name) {
	location.href = "/ev/event_down?f_name=" + f_name;
}

// 녹지 행사 관리 수정하기
function admin_event_update(f) {
	f.action = "/ev/update";
	f.submit();
}

function admin_event_update_ok(f) {
	f.action = "/ev/updateok";
	f.submit();
}

// 녹지 행사 관리 삭제하기
function admin_event_delete(f) {
	f.action = "/ev/delete";
	f.submit();
}

function admin_event_delete_ok(f) {
	f.action = "/ev/deleteok";
	f.submit();
}



// 게시판 댓글 관리
function admin_comment_list(cPage) {
	location.href = `/admin/commentlist?cPage=${cPage || 1}`;
}

function admin_comment_delete(f) {
	f.action = "/admin/commentdelete";
	f.submit();
}

// 리뷰 관리
function admin_review_list() {
	location.href = "/admin/reviewlist";
}

function admin_review_detail() {
	location.href = "/admin/reviewdetail";
}


function admin_review_down(f_name) {
	location.href = "/admin/review_down?f_name=" + f_name;
}


function admin_review_update_ok(f) {
	f.action = "/admin/reviewupdateok";
	f.submit();
}

// 리뷰 관리 삭제하기
function admin_review_delete(f) {
	f.action = "/admin/reviewdelete";
	f.submit();
}

function admin_review_delete_ok(f) {
	f.action = "/admin/reviewdeleteok";
	f.submit();
}



// 팝업 관리
function popup_list() {
	location.href = "/pop/list";
}

function popup_detail() {
	location.href = "/pop/detail";
}

// 팝업 관리 글쓰기
function popup_write() {
	location.href = "/pop/insert";
}

function popup_write_ok(f) {
	f.action = "/pop/insertok";
	f.submit();
}


function popup_down(f_name) {
	location.href = "/popup_down?f_name=" + f_name;
}

// 팝업 관리 수정하기
function popup_update(f) {
	f.action = "/pop/update";
	f.submit();
}

function popup_update_ok(f) {
	f.action = "/pop/updateok";
	f.submit();
}

// 팝업 관리 삭제하기
function popup_delete(f) {
	f.action = "/pop/delete";
	f.submit();
}

function popup_delete_ok(f) {
	f.action = "/pop/deleteok";
	f.submit();
}
