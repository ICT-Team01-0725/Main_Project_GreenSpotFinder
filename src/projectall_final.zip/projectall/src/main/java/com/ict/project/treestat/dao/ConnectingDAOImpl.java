package com.ict.project.treestat.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.project.treestat.vo.ConnectionVO;


@Repository
public class ConnectingDAOImpl implements ConnectingDAO {

	@Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    // 기본 공원 리스트 조회
    @Override
    public List<ConnectionVO> getConnectionPark(int offset, int limit) {
    	Map<String, Integer> map = new HashMap<String, Integer>();
    	map.put("offset", offset);
    	map.put("limit", limit);
    	return sqlSessionTemplate.selectList("connectionpark.list", map);  // 쿼리 호출
    }

    // 공원명으로 검색
    @Override
    public List<ConnectionVO> getSearchPark(String searchPark) {
        return sqlSessionTemplate.selectList("connectionpark.name", searchPark);  // 쿼리 호출
    }

	@Override
	public int parkCount() {
		return sqlSessionTemplate.selectOne("connectionpark.count");
	}
}