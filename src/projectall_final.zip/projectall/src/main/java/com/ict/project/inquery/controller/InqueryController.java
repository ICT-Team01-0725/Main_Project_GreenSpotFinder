package com.ict.project.inquery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ict.project.admin.service.AdminService;
import com.ict.project.admin.vo.AdminVO;
import com.ict.project.comm.Paging;
import com.ict.project.comm.PagingService;
import com.ict.project.comm.PerPageConstant;
import com.ict.project.inquery.service.InqueryService;
import com.ict.project.inquery.vo.InqueryVO;

@Controller
public class InqueryController {
	
	@Autowired
	private InqueryService inqueryService;
	@Autowired
	private PagingService pagingService;
	@Autowired
	private AdminService adminService;
	
	
	@RequestMapping("/inquery/list")
	public ModelAndView getInqueryList(HttpServletRequest request){
		ModelAndView mv = new ModelAndView("sub/inquery_list");
		
		int count = inqueryService.getInqueryCount();
		// pagingservice 메서드에 넣을 값
		
		String cPage = request.getParameter("cPage");
		if(cPage==null||cPage.isEmpty()) {
			cPage = "1";
		}
		PerPageConstant pageConstant = new PerPageConstant();
		int perpage = pageConstant.getFreeboardpage();
				
		// 페이징 기법 설정
		Paging paging = pagingService.pagingservice(count, cPage, perpage);
		// DB 갔다가 오기 
		List<InqueryVO> list = inqueryService.getInqueryList(paging.getOffset(), paging.getNumPerPage());
		
		mv.addObject("list", list);
		mv.addObject("paging", paging);
		mv.addObject("cmd", "/inquery/list");
		
		return mv;
	}
	
	@PostMapping("/inquery/detail")
	public ModelAndView getInqueryDetail(String i_idx) {
		ModelAndView mv = new ModelAndView("sub/inquery_detail");
		InqueryVO ivo = inqueryService.getInqueryDetail(i_idx);
		mv.addObject("ivo", ivo);
		return mv;
	}
	
	@PostMapping("/inquery/insert")
	public ModelAndView getInqueryInsert(InqueryVO ivo) {
		ModelAndView mv = new ModelAndView("redirect:/inquery/list");
		inqueryService.getInqueryInsert(ivo);
		return mv;
	}
	
	@RequestMapping("/inquery/insertgo")
	public ModelAndView getInqueryInsertGo(HttpSession session) {
		Object u_id = session.getAttribute("u_id"); 
		if(u_id != null) {
		ModelAndView mv = new ModelAndView("sub/inquery_write");
		mv.addObject("u_id", u_id);
		return mv;
		}
		System.out.println("로그인이 되지 않음");
		return new ModelAndView("index");
	}
	
	
	@PostMapping("/inquery/delete")
	public ModelAndView getInqueryDelete(String idx) {
		ModelAndView mv = new ModelAndView("redirect:/inquery/list");
		inqueryService.getInqueryDelete(idx);
		return mv;
	}
	
}
