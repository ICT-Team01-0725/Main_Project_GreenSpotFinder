package com.ict.project.treestat.dao;

import java.util.List;

import com.ict.project.treestat.vo.TableTreeVO;


public interface searchTreeDAO {
	
	public int getCountTree();

	public List<TableTreeVO> getSearchTree(int offset, int limit);

	public List<TableTreeVO> getSearchBar(String treename);

	public List<TableTreeVO> getSortedTrees(String category);

	public List<TableTreeVO> getSortedByAddress();

	public List<TableTreeVO> getSortedByDate();

	public List<TableTreeVO> getSortedByAge();

}
