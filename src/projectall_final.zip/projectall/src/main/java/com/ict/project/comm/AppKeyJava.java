package com.ict.project.comm;

public class AppKeyJava {
	private String kakaoJavaScript = "0e4ccdb548ca74e6213debb7aad29378";
	private String kakaoRestApi = "673fbc7db4cc9805a5120f9f38a7289a";
	private String kakaoClientSecret = "WdAz4aeZDRQoNzqnC00TmUVwrxlctYqq";
	private String naverClientId = "bv_786diGR8Y0y00e9Bx";
	private String naverClientSecret = "mZsU2OCm0L";
	public String getKakaoJavaScript() {
		return kakaoJavaScript;
	}
	public String getKakaoRestApi() {
		return kakaoRestApi;
	}
	public String getKakaoClientSecret() {
		return kakaoClientSecret;
	}
	public String getNaverClientId() {
		return naverClientId;
	}
	public String getNaverClientSecret() {
		return naverClientSecret;
	}
	
}
