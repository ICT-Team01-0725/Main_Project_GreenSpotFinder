package com.ict.project.finalsearchpark.service;

import java.util.List;

import com.ict.project.finalsearchpark.vo.FinalSearchParkVO;



public interface FinalSearchParkService {
    // 주소로 공원 검색
    public List<FinalSearchParkVO> searchParkByAddress(String p_ad, int offset, int limit);

    public int searchParkCount();
}