package com.ict.project.fna.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ict.project.admin.service.AdminService;
import com.ict.project.admin.vo.AdminVO;
import com.ict.project.comm.Paging;
import com.ict.project.comm.PagingService;
import com.ict.project.comm.PerPageConstant;
import com.ict.project.fna.service.FnaService;
import com.ict.project.fna.vo.FnaVO;

@Controller
public class FnaController {
	
	@Autowired
	private FnaService fnaService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private PagingService pagingService;
	
	
	@GetMapping("/fna/list")
	public ModelAndView getFnaList(HttpServletRequest request){
		ModelAndView mv = new ModelAndView("sub/fna_list");
		
		int count = fnaService.getFnaCount();
		// pagingservice 메서드에 넣을 값
		String cPage = request.getParameter("cPage");
		if(cPage==null||cPage.isEmpty()) {
			cPage = "1";
		}
		PerPageConstant pageConstant = new PerPageConstant();
		int perpage = pageConstant.getFnapage();
				
		// 페이징 기법 설정
		Paging paging = pagingService.pagingservice(count, cPage, perpage);
		// DB 갔다가 오기 
		List<FnaVO> list = fnaService.getFnaList(paging.getOffset(), paging.getNumPerPage());
		
		mv.addObject("list", list);
		mv.addObject("paging", paging);
		mv.addObject("cmd", "/fna/list");
		
		System.out.println("총페이지 : "+paging.getTotalPage());
		System.out.println("시작블럭 : "+paging.getBeginBlock());
		System.out.println("끝블럭 : "+paging.getEndBlock());
		
		return mv;
	}
	
	@RequestMapping("/fna/detail")
	public ModelAndView getFnaDetail(String f_idx, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("sub/fna_detail");
		String cPage = request.getParameter("cPage");
		FnaVO fvo = fnaService.getFnaDetail(f_idx);
		System.out.println(fvo);
		System.out.println(f_idx);
		System.out.println(fvo.getA_idx());
		if(fvo.getA_idx()!=null) {
			AdminVO avo = adminService.adminDetail(fvo.getA_idx());
			mv.addObject("a_id", avo.getA_id());
		}
		mv.addObject("fvo", fvo);
		mv.addObject("cPage", cPage);
		return mv;
	}
	
	@PostMapping("/fna/insert")
	public ModelAndView getFnaInsert(FnaVO fvo) {
		ModelAndView mv = new ModelAndView("redirect:/fna/list");
		fnaService.getFnaInsert(fvo);
		return mv;
	}
	
	@PostMapping("/fna/update")
	public ModelAndView getFnaUpdate(FnaVO fvo) {
		ModelAndView mv = new ModelAndView("redirect:/fna/detail?f_idx="+fvo.getF_idx());
		fnaService.getFnaUpdate(fvo);
		return mv;
	}
	
	@PostMapping("/fna/delete")
	public ModelAndView getFnaDelete(String f_idx) {
		ModelAndView mv = new ModelAndView("redirect:/fna/list");
		fnaService.getFnaDelete(f_idx);
		return mv;
	}
	
}
