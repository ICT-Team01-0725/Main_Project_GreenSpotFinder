package com.ict.project.sub4_2.vo;

public class Sub4_2VO {
	
	private String ev_idx, ev_na, ev_s_dat, ev_e_dat, ev_ce_num;

	public String getEv_idx() {
		return ev_idx;
	}

	public void setEv_idx(String ev_idx) {
		this.ev_idx = ev_idx;
	}

	public String getEv_na() {
		return ev_na;
	}

	public void setEv_na(String ev_na) {
		this.ev_na = ev_na;
	}

	public String getEv_s_dat() {
		return ev_s_dat;
	}

	public void setEv_s_dat(String ev_s_dat) {
		this.ev_s_dat = ev_s_dat;
	}

	public String getEv_e_dat() {
		return ev_e_dat;
	}

	public void setEv_e_dat(String ev_e_dat) {
		this.ev_e_dat = ev_e_dat;
	}

	public String getEv_ce_num() {
		return ev_ce_num;
	}

	public void setEv_ce_num(String ev_ce_num) {
		this.ev_ce_num = ev_ce_num;
	}
	
	
}
