package com.ict.project.login.service;

public interface EmailService {
	
	public void sendemail(String r_num, String tomail);
	
}
