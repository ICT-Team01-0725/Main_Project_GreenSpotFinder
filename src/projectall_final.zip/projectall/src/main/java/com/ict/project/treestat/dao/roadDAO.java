package com.ict.project.treestat.dao;

import java.util.List;

import com.ict.project.treestat.vo.roadVO;


public interface roadDAO {

	int roadCount();
	List<roadVO> roadSearchByAddress(String searchKeyword, int offset);
}
