package com.ict.project.finalsearchpark.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.project.finalsearchpark.vo.FinalSearchParkVO;


@Repository
public class FinalSearchParkDAOImpl implements FinalSearchParkDAO {

    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    @Override
    public List<FinalSearchParkVO> searchParkByAddress(String p_ad, int offset, int limit) {
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("p_ad", p_ad);
    	map.put("offset", offset);
    	map.put("limit", limit);
    	
        return sqlSessionTemplate.selectList("finalsearchpark-mapper.searchParkByAddress", map);
    }


	@Override
	public int searchParkCount() {
		return sqlSessionTemplate.selectOne("finalsearchpark-mapper.searchparkcount");
	}
}