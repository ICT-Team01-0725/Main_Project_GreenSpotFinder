package com.ict.project.finalroadsearch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.project.finalroadsearch.dao.FinalRoadSearchDAO;
import com.ict.project.finalroadsearch.vo.FinalRoadSearchVO;


@Service
public class FinalRoadSearchServiceImpl implements FinalRoadSearchService {

    @Autowired
    private FinalRoadSearchDAO finalRoadSearchDAO;

    @Override
    public List<FinalRoadSearchVO> searchRoadByAddress(String r_ce_ad) {
        return finalRoadSearchDAO.searchRoadByAddress(r_ce_ad);
    }

    @Override
    public List<FinalRoadSearchVO> searchRoadByRegion(String region) {
        return finalRoadSearchDAO.searchRoadByRegion(region);
    }
}