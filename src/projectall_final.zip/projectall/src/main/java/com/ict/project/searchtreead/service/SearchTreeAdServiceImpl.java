package com.ict.project.searchtreead.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.project.searchtreead.vo.SearchTreeAdVO;


@Service
public class SearchTreeAdServiceImpl implements SearchTreeAdService {

    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    @Override
    public List<SearchTreeAdVO> searchTreesByAddress(String address) {
        return sqlSessionTemplate.selectList("searchtreead.searchTreesByAddress", address);
    }

    @Override
    public List<SearchTreeAdVO> getTop4Trees() {
        return sqlSessionTemplate.selectList("searchtreead.getTop4Trees");
    }

    @Override
    public List<SearchTreeAdVO> getAllTrees() {
        return sqlSessionTemplate.selectList("searchtreead.getAllTrees");
    }

    @Override
    public List<SearchTreeAdVO> searchTreesByRegion(String region) {
        return sqlSessionTemplate.selectList("searchtreead.searchTreesByRegion", region);
    }
}