package com.ict.project.treestat.vo;

public class TableTreeVO {
	
	private String t_sta_idx, t_sta_info, t_sta_spec_, t_sta_ad, t_sta_dat, t_sta_age;

	public String getT_sta_idx() {
		return t_sta_idx;
	}

	public void setT_sta_idx(String t_sta_idx) {
		this.t_sta_idx = t_sta_idx;
	}

	public String getT_sta_info() {
		return t_sta_info;
	}

	public void setT_sta_info(String t_sta_info) {
		this.t_sta_info = t_sta_info;
	}

	public String getT_sta_spec_() {
		return t_sta_spec_;
	}

	public void setT_sta_spec_(String t_sta_spec_) {
		this.t_sta_spec_ = t_sta_spec_;
	}

	public String getT_sta_ad() {
		return t_sta_ad;
	}

	public void setT_sta_ad(String t_sta_ad) {
		this.t_sta_ad = t_sta_ad;
	}

	public String getT_sta_dat() {
		return t_sta_dat;
	}

	public void setT_sta_dat(String t_sta_dat) {
		this.t_sta_dat = t_sta_dat;
	}

	public String getT_sta_age() {
		return t_sta_age;
	}

	public void setT_sta_age(String t_sta_age) {
		this.t_sta_age = t_sta_age;
	} 
	
}