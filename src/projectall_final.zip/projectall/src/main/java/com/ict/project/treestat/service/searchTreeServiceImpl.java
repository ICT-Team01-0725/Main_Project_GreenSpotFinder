package com.ict.project.treestat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.project.treestat.vo.TableTreeVO;



@Service
public class searchTreeServiceImpl implements searchTreeService {

	@Autowired
	private com.ict.project.treestat.dao.searchTreeDAO searchTreeDAO;
	
	@Override
	public List<TableTreeVO> getSearchTree(int offset, int limit) {
		return searchTreeDAO.getSearchTree(offset, limit);
	}

	@Override
	public List<TableTreeVO> getSearchBar(String treename) {
		 
		return searchTreeDAO.getSearchBar(treename);
	}

	
	// select 값
	@Override
	public List<TableTreeVO> getSortedTrees(String category) {
		
	     switch (category) {
         case "address":
             return searchTreeDAO.getSortedByAddress();  // 주소순 정렬
         case "date":
             return searchTreeDAO.getSortedByDate();  // 지정일순 정렬
         case "age":
             return searchTreeDAO.getSortedByAge();   // 수령순 정렬
     }
		return null;
		
		
	}

	@Override
	public int getCountTree() {
		return searchTreeDAO.getCountTree();
	}
}
