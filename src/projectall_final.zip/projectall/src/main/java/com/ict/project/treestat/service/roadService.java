package com.ict.project.treestat.service;

import java.util.List;

import com.ict.project.treestat.vo.roadVO;



public interface roadService {

	public List<roadVO> roadSearchByAddress(String searchKeyword, int offset);
	public int roadcount();
}
