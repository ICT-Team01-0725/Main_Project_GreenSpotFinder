package com.ict.project.treestat.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.project.treestat.vo.roadVO;


@Repository
public class roadDAOImpl implements roadDAO {

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public List<roadVO> roadSearchByAddress(String searchKeyword, int offset) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("searchKeyword", searchKeyword);
		map.put("offset", offset);

		return sqlSessionTemplate.selectList("road.searchRoadByAddress", map);
	}

	@Override
	public int roadCount() {
		return sqlSessionTemplate.selectOne("road.roadcount");
	}

}
