package com.ict.project.treestat.service;

import java.util.List;

import com.ict.project.treestat.vo.TableTreeVO;


public interface searchTreeService {
	
	public int getCountTree();

	public List<TableTreeVO> getSearchTree(int offset, int limit);
	
	 public List<TableTreeVO> getSearchBar(String treename);

	 public List<TableTreeVO> getSortedTrees(String category);
	
}
