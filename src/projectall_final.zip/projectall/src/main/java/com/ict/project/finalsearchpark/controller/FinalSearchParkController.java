package com.ict.project.finalsearchpark.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ict.project.comm.Paging;
import com.ict.project.comm.PagingService;
import com.ict.project.comm.PerPageConstant;
import com.ict.project.finalsearchpark.service.FinalSearchParkService;
import com.ict.project.finalsearchpark.vo.FinalSearchParkVO;


@Controller
public class FinalSearchParkController {

    @Autowired
    private FinalSearchParkService finalSearchParkService;
    
    @Autowired
    private PagingService pagingService;

    // 메인 화면 표시 (기본 화면에 지역별 공원 리스트를 보여주는 부분)
    @GetMapping("/sub1-2")
    public ModelAndView showMainPage(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("sub/sub1-2"); // JSP 뷰 이름
        
        String cPage = request.getParameter("cPage");
        if(cPage==null||cPage.isEmpty()) {
			cPage = "1";
		}
        System.out.println(cPage);
        int count = finalSearchParkService.searchParkCount();
        PerPageConstant perPageConstant = new PerPageConstant();
        int perPage = perPageConstant.getParkpage();
        
        Paging paging = pagingService.pagingservice(count, cPage, perPage);
        		
        List<FinalSearchParkVO> parkList = finalSearchParkService.searchParkByAddress("서울", paging.getOffset(), perPage); // 기본적으로 서울 데이터 가져오기
        
        System.out.println("이런 젠장");
        
        mv.addObject("parkList", parkList);
        mv.addObject("paging", paging);
        mv.addObject("cmd", "/sub1-2");
        return mv;
    }


    // 주소로 공원 검색
    @GetMapping("/searchParkByAddress")
    public ModelAndView searchParkByAddress(@RequestParam(value = "address", required = false) String address, HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("sub/sub1-2");
        
        String cPage = request.getParameter("cPage");
        if(cPage==null||cPage.isEmpty()) {
			cPage = "1";
		}
        System.out.println(cPage);
        int count = finalSearchParkService.searchParkCount();
        PerPageConstant perPageConstant = new PerPageConstant();
        int perPage = perPageConstant.getParkpage();
        
        Paging paging = pagingService.pagingservice(count, cPage, perPage);
        // 주소로 공원 검색
        if (address != null && !address.isEmpty()) {
            List<FinalSearchParkVO> searchResult = finalSearchParkService.searchParkByAddress(address, paging.getOffset(), perPage);
            mv.addObject("parkList", searchResult);
        } else {
            mv.addObject("parkList", null); // 검색 결과 없음
        }

        return mv;
    }
}