package com.ict.project.treestat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.project.treestat.vo.roadVO;



@Service
public class roadServiceImpl implements roadService {

	@Autowired
	private com.ict.project.treestat.dao.roadDAO roadDAO;
	

	@Override
	public List<roadVO> roadSearchByAddress(String searchKeyword, int offset) {
         System.out.println("데어터 : " + searchKeyword);
		return roadDAO.roadSearchByAddress(searchKeyword, offset);
	}


	@Override
	public int roadcount() {
		return roadDAO.roadCount();
	}
	
}
