package com.ict.project.sub4_1.controller;

import java.io.FileReader;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ict.project.sub4_2.vo.Sub4_2VO;

@RestController
public class Sub4_1Controller {
	
	@RequestMapping("/sub4-1json")
	public List<Sub4_2VO> getEvent(HttpServletRequest request){
		Gson gson = new Gson();
		try {
			FileReader reader = new FileReader(request.getSession().getServletContext().getRealPath("/resources/json/calendar_mock.json"));
			List<Sub4_2VO> fulllist = gson.fromJson(reader, new TypeToken<List<Sub4_2VO>>(){}.getType());
			
			return fulllist;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
		
	}
}
