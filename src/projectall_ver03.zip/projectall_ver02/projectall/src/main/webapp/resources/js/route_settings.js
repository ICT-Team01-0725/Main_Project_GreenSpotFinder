// 경로 이동 설정 start
// 메인
function move_main() {
	location.href = "/mainGo";
}

// 통합검색
function move_total_search() {
	location.href = "/totalSearch";
}

// 로그인
function move_login() {
	location.href = "/loginGo";
}

// 로그아웃
function move_logout() {
	location.href = "/logout";
}

// 회원가입
function move_join() {
	location.href = "/joinGo";
}

// 1. 공원 찾기
// 공원 이야기
function move_sub1_1() {
	location.href = "/sub1-1";
}
// 지역별 공원 찾기
function move_sub1_2() {
	location.href = "/sub1-2";
}
// 면적별 공원 찾기
function move_sub1_3() {
	location.href = "/sub1-3";
}
// 공원 연락하기
function move_sub1_4() {
	location.href = "/sub1-4";
}

// 2. 가로수길 찾기
// 가로수길 걷기
function move_sub2_1() {
	location.href = "/sub2-1";
}
// 지역별 가로수길 찾기
function move_sub2_2() {
	location.href = "/sub2-2";
}
// 산책코스 찾기
function move_sub2_3() {
	location.href = "/sub2-3";
}
// 가로수길 수목 조회
function move_sub2_4() {
	location.href = "/sub2-4";
}

// 3. 지역 속 보호수
// 가로수길 걷기
function move_sub3_1() {
	location.href = "/sub3-1";
}
// 지역별 가로수길 찾기
function move_sub3_2() {
	location.href = "/sub3-2";
}
// 산책코스 찾기
function move_sub3_3() {
	location.href = "/sub3-3";
}

// 4. 녹지 행사
// 날짜별 행사 찾기
function move_sub4_1() {
	location.href = "/sub4-1";
}
// 지역별 행사 찾기
function move_sub4_2() {
	location.href = "/sub4-2";
}

// 5. 커뮤니티
// 공지사항 리스트
function move_notice() {
	location.href = "/notice";
}

// 공지사항 글쓰기
function move_notice_write() {
	location.href = "/notice_write";
}


function move_notice_write_ok(f) {
	f.action = "/notice_write_ok";
	f.submit();
}


// 공지사항 상세보기
function move_notice_detail(n_idx, cPage) {
	// alert("n_idx : " + n_idx);
	// alert("cPage : " + cPage);
	location.href = "/notice_detail?n_idx=" + n_idx + "&cPage=" + cPage;
}

function move_notice_down(f_name) {
	location.href = "/notice_down?f_name=" + f_name;
}

function move_comment_delete(f) {
	f.action = "/comment_delete";
	f.submit();
}

// 공지사항 수정하기
function move_notice_update(f) {
	f.action = "/notice_update";
	f.submit();
}

function move_notice_update_ok(f) {
	f.action = "/notice_update_ok";
	f.submit();
}

// 공지사항 삭제하기
function move_notice_delete(f) {
	f.action = "/notice_delete";
	f.submit();
}

function move_notice_delete_ok(f) {
	f.action = "/notice_delete_ok";
	f.submit();
}

// 리뷰 리스트
function move_review() {
	location.href = "/review";
}
// 리뷰 글쓰기
function move_review_write() {
	location.href = "/review_write";
}
// 리뷰 상세보기
function move_review_detail(rev_idx) {
	location.href = "/review_detail?c_bor=review&c_ref="+rev_idx+"&cPage=1";
}

// 고객의 소리 리스트
function move_customer() {
	location.href = "/customer";
}
// 고객의 소리 글쓰기
function move_customer_write() {
	location.href = "/customer_write";
}
// 고객의 소리 상세보기
function move_customer_detail() {
	location.href = "/customer_detail";
}

// 자주하는 질문 리스트
function move_fna_list(cPage) {
	location.href = `/fna/list?cPage=${cPage || "1"}`;
}
// 자주하는 질문 리스트
function move_fna_detail(f_idx, cPage) {
	location.href = `/fna/detail?idx=${f_idx}&cPage=${cPage || "1"}`;
}

// 1:1 문의 리스트
function move_qna() {
	location.href = "/qna/list";
}
// 1:1 문의 글쓰기
function move_qna_write() {
	location.href = "/qna/insertgo";
}
// 1:1 문의 상세보기
function move_qna_detail() {
	location.href = "/qna/detail";
}

function qna_write_user(f) {
	f.action = "/qna/insert";
	f.submit();
}
// 마이 페이지
// 마이페이지
function move_mypage_main() {
	location.href = "/mypageMain";
}

// 관리자
function move_accounts() {
	location.href = "/admin_go";
}


// 히스토리 -> 캘린더
function my_calendar() {
	location.href = "/my_calendar";
}

// 히스토리 -> 스크랩
function my_scraps() {
	location.href = "/my_scraps";
}

function scraps_category() {
	location.href = "/my_scraps";
}

// 히스토리 -> 내가 쓴 리뷰
function my_review() {
	location.href = "/my_review";
}

// 히스토리 -> 내가 쓴 게시판
function my_board() {
	location.href = "/my_board";
}

// 내 정보 보기 -> 내 프로필
function my_info_check() {
	location.href = "/my_info_check";
}

// 내 정보 보기 -> 회원정보 수정
function my_info_mody() {
	location.href = "/my_info_mody";
}

// 내 정보 보기 -> 회원정보 삭제
function my_info_delete() {
	location.href = "/my_info_delete";
}

// 문의 내역 -> 1 : 1 문의 내역
function my_qna() {
	location.href = "/my_qna";
}

// 문의 내역 -> 불편사항 신고 내역
function my_report() {
	location.href = "/my_report";
}




// footer 정보

// 개인정보처리방침
function privacy() {
	location.href = "/privacy";
}

// 이용약관
function terms_of_use() {
	location.href = "/terms_of_use";
}
// 경로 이동 설정 end



// 팝업 
function popupClose() {
	$('.popuplayout').css({'display':'none'});
}

function popupTodayClose() {
	$('.popuplayout').css({'display':'none'});
}