package com.ict.project.index.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ict.project.notice.service.NoticeService;
import com.ict.project.notice.vo.NoticeVO;
import com.ict.project.review.service.ReviewService;
import com.ict.project.review.vo.ReviewVO;

@RestController
public class IndexController {
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private ReviewService reviewService;
	
	@RequestMapping("/noticeindex")
	@ResponseBody
	public List<NoticeVO> indexNotice() {
		List<NoticeVO> noticelist = noticeService.getNoticeIndex(4);
		
		return noticelist;
	}
	
	@RequestMapping("/reviewindex")
	@ResponseBody
	public List<ReviewVO> indexreview(){
		List<ReviewVO> reviewlist = reviewService.getReviewindex(6);
		
		return reviewlist;
	}
	
	
}
