package com.ict.project.treestat.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.project.treestat.vo.searchTreeVO;


@Repository
public class searchTreeDAOImpl implements searchTreeDAO {

    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<searchTreeVO> getSearchTree(int offset, int limit) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("offset", offset);
		map.put("limit", limit);
		return sqlSessionTemplate.selectList("searchTree.list", map);
		
	}

	// 검색
	@Override
	public List<searchTreeVO> getSearchBar(String treename) {
		return sqlSessionTemplate.selectList("searchTree.searchbar" ,treename);
	}

	// select 정렬 ?
    @Override
    public List<searchTreeVO> getSortedTrees(String category) {
        return sqlSessionTemplate.selectList("searchTree.sortByCategory", category);
    }
   
	// 주소로 정렬
	@Override
    public List<searchTreeVO> getSortedByAddress() {
        return sqlSessionTemplate.selectList("searchTree.sortByAddress");
    }
    
    // 지정일에 정렬
    @Override
    public List<searchTreeVO> getSortedByDate() {
        return sqlSessionTemplate.selectList("searchTree.sortByDate");
    }
    
    // 나이에 정렬
    @Override
    public List<searchTreeVO> getSortedByAge() {
        return sqlSessionTemplate.selectList("searchTree.sortByAge");
    }

	@Override
	public int getCountTree() {
		return sqlSessionTemplate.selectOne("searchTree.counttree");
	}


}
