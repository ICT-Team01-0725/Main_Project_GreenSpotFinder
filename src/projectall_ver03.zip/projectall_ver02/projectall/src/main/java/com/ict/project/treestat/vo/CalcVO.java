package com.ict.project.treestat.vo;


public class CalcVO {
    private String r_ce_ad;
    private String r_ty;
    private int r_vol;
    private double dist_km;

    // Getters and Setters
    public String getR_ce_ad() {
        return r_ce_ad;
    }
    public void setR_ce_ad(String r_ce_ad) {
        this.r_ce_ad = r_ce_ad;
    }
    public String getR_ty() {
        return r_ty;
    }
    public void setR_ty(String r_ty) {
        this.r_ty = r_ty;
    }
    public int getR_vol() {
        return r_vol;
    }
    public void setR_vol(int r_vol) {
        this.r_vol = r_vol;
    }
    public double getDist_km() {
        return dist_km;
    }
    public void setDist_km(double dist_km) {
        this.dist_km = dist_km;
    }
}
