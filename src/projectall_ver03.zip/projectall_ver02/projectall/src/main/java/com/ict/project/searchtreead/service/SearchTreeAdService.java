package com.ict.project.searchtreead.service;

import java.util.List;

import com.ict.project.searchtreead.vo.SearchTreeAdVO;


public interface SearchTreeAdService {


    List<SearchTreeAdVO> searchTreesByAddress(String address);
    
    List<SearchTreeAdVO> getTop4Trees();
    
    List<SearchTreeAdVO> getAllTrees();
    
    List<SearchTreeAdVO> searchTreesByRegion(String region);
    
}
