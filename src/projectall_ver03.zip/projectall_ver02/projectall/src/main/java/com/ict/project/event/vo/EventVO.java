package com.ict.project.event.vo;

public class EventVO {
	
	private String ev_idx, ev_name, ev_lat, ev_long, ev_sdat, ev_edat, ev_tle, ev_ty, ev_ce_na, ev_pho;

	public String getEv_idx() {
		return ev_idx;
	}

	public void setEv_idx(String ev_idx) {
		this.ev_idx = ev_idx;
	}

	public String getEv_name() {
		return ev_name;
	}

	public void setEv_name(String ev_name) {
		this.ev_name = ev_name;
	}

	public String getEv_lat() {
		return ev_lat;
	}

	public void setEv_lat(String ev_lat) {
		this.ev_lat = ev_lat;
	}

	public String getEv_long() {
		return ev_long;
	}

	public void setEv_long(String ev_long) {
		this.ev_long = ev_long;
	}

	public String getEv_sdat() {
		return ev_sdat;
	}

	public void setEv_sdat(String ev_sdat) {
		this.ev_sdat = ev_sdat;
	}

	public String getEv_edat() {
		return ev_edat;
	}

	public void setEv_edat(String ev_edat) {
		this.ev_edat = ev_edat;
	}

	public String getEv_tle() {
		return ev_tle;
	}

	public void setEv_tle(String ev_tle) {
		this.ev_tle = ev_tle;
	}

	public String getEv_ty() {
		return ev_ty;
	}

	public void setEv_ty(String ev_ty) {
		this.ev_ty = ev_ty;
	}

	public String getEv_ce_na() {
		return ev_ce_na;
	}

	public void setEv_ce_na(String ev_ce_na) {
		this.ev_ce_na = ev_ce_na;
	}

	public String getEv_pho() {
		return ev_pho;
	}

	public void setEv_pho(String ev_pho) {
		this.ev_pho = ev_pho;
	}
}
