package com.ict.project.treestat.vo;


public class ConnectionVO {

	private String p_na, p_ad, p_pho;

	public String getP_na() {
		return p_na;
	}

	public void setP_na(String p_na) {
		this.p_na = p_na;
	}

	public String getP_ad() {
		return p_ad;
	}

	public void setP_ad(String p_ad) {
		this.p_ad = p_ad;
	}

	public String getP_pho() {
		return p_pho;
	}

	public void setP_pho(String p_pho) {
		this.p_pho = p_pho;
	}
	
}
