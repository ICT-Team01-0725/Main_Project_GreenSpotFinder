package com.ict.project.treestat.service;

import java.util.List;

import com.ict.project.treestat.vo.searchTreeVO;


public interface searchTreeService {
	
	public int getCountTree();

	public List<searchTreeVO> getSearchTree(int offset, int limit);
	
	 public List<searchTreeVO> getSearchBar(String treename);

	 public List<searchTreeVO> getSortedTrees(String category);
	
}
