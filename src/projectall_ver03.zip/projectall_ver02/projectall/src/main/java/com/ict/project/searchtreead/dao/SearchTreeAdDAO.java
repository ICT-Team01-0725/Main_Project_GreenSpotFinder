package com.ict.project.searchtreead.dao;

import java.util.List;

import com.ict.project.searchtreead.vo.SearchTreeAdVO;


public interface SearchTreeAdDAO {

    List<SearchTreeAdVO> searchTreesByAddress(String t_sta_ad);
    
    List<SearchTreeAdVO> getTop4Trees();
}