package com.ict.project.treestat.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ict.project.comm.Paging;
import com.ict.project.comm.PagingService;
import com.ict.project.comm.PerPageConstant;
import com.ict.project.treestat.service.CalorieService;
import com.ict.project.treestat.service.ConnectingService;
import com.ict.project.treestat.vo.ConnectionVO;
import com.ict.project.treestat.vo.roadVO;
import com.ict.project.treestat.vo.searchTreeVO;


@Controller
public class TreeStatController {

	@Autowired
	private com.ict.project.treestat.service.roadService roadService;
	
	@Autowired
	private ConnectingService connectingService;
	
	@Autowired
	private com.ict.project.treestat.service.searchTreeService searchTreeService;

	@Autowired
	private CalorieService calorieService;
	
	@Autowired
	private PagingService pagingService;
	
	@GetMapping("/searchRoad")
	public ModelAndView searchParks(@RequestParam(value = "searchKeyword", required = false) String searchKeyword) {

		ModelAndView mv = new ModelAndView("/index");

		if (searchKeyword == null || searchKeyword.trim().isEmpty()) {
			System.out.println("값이 없다");
		} else {
			System.out.println("검색어: " + searchKeyword);
		}

		List<roadVO> roadList = roadService.roadSearchByAddress(searchKeyword);
    
		mv.addObject("startLon", roadList.get(0).getR_s_lon());
		mv.addObject("startLat", roadList.get(0).getR_s_lat());
		mv.addObject("endLat", roadList.get(0).getR_e_lat());
		mv.addObject("endLon", roadList.get(0).getR_e_lon());
		mv.addObject("searchKeyword", searchKeyword);
		mv.addObject("treetype", roadList.get(0).getR_ty()); // 나무 종류
		mv.addObject("course", roadList.get(0).getR_rsec()); // 경로
		mv.addObject("treecount", roadList.get(0).getR_vol()); // 나무의 수 
		mv.addObject("length", roadList.get(0).getR_len()); // 거리
         System.out.println(roadList.get(0).getR_s_lat());
         System.out.println(roadList.get(0).getR_s_lon());
         System.out.println(roadList.get(0).getR_e_lat());
         System.out.println(roadList.get(0).getR_e_lon());
         double calories = calorieService.calculateCalories(65, roadList.get(0).getR_len()/4.8); 
         calories = ((int)(calories*100))/100.0;
		System.out.println("칼로리:"+calories);
         mv.addObject("calories", calories);
         return mv;
	}

	/*
	 * @RequestMapping() public ModelAndView getMoveSub1_4() { return new
	 * ModelAndView("sub/sub1-4"); }
	 */	

	
	// 공원 리스트 불러오기 완료
	@GetMapping("/sub1-4")
	public ModelAndView getConnectionPark() {
		ModelAndView mv = new ModelAndView("sub/sub1-4");
		List<ConnectionVO> cvo = connectingService.getConnectionPark();
		mv.addObject("cvo", cvo);
		System.out.println(cvo.get(0).getP_ad());
		return mv;
	}
	
	
	
	
	// 공원명 검색 완료
    @GetMapping("/searchBar")
    public String searchParks(@RequestParam("searchPark") String searchPark, HttpServletRequest request) {
        // 공원명으로 검색한 결과를 가져옵니다.
        List<ConnectionVO> cvo = connectingService.getSearchPark(searchPark);

        // 검색 결과가 없다면 빈 리스트로 처리
        if (cvo.isEmpty()) {
            request.setAttribute("message", "원하는 정보가 존재하지 않습니다.");
        }

        // 검색 결과를 request 객체에 담아 JSP로 전달
        request.setAttribute("cvo", cvo);
        request.setAttribute("searchPark", searchPark);  // 검색한 공원명
        
        return "sub/sub1-4";  // 검색 결과 페이지로 이동
    }
    

    // 보호수 리스트 불러오기 완료
    @RequestMapping("/sub3-3")
    public ModelAndView showTree(HttpServletRequest request) {
    	ModelAndView mv = new ModelAndView("/sub/sub3-3");
    	
    	String cPage = request.getParameter("cPage");
    	PerPageConstant perPageConstant = new PerPageConstant();
    	int perPage = perPageConstant.getTreepage();
    	int count = searchTreeService.getCountTree();
    	Paging paging = pagingService.pagingservice(count, cPage, perPage);
    	
    	int offset = paging.getOffset();
    	
		List<searchTreeVO> svo = searchTreeService.getSearchTree(offset, perPage);
		mv.addObject("svo", svo);
		System.out.println();
		return mv;
    	
    }
    
    
    // 보호수 검색창 검색 완료
    @GetMapping("searchTreeAddress")
    public String searchTreeAddress(@RequestParam("treename") String treename, HttpServletRequest request) {
        // 공원명으로 검색한 결과를 가져옵니다.
        List<searchTreeVO> svo = searchTreeService.getSearchBar(treename) ;

        // 검색 결과가 없다면 빈 리스트로 처리
        if (svo.isEmpty()) {
            request.setAttribute("message", "원하는 정보가 존재하지 않습니다.");
        }

        // 검색 결과를 request 객체에 담아 JSP로 전달
        request.setAttribute("svo", svo);
        request.setAttribute("treename", treename);  // 검색한 공원명
        
        return "sub/sub3-3";  // 검색 결과 페이지로 이동
    }
 
    @GetMapping("/sortby")
    public String searchTree(@RequestParam(value = "category", defaultValue = "address") String category, HttpServletRequest request) {
    	List<searchTreeVO> sortedList =  searchTreeService.getSortedTrees(category);
        request.setAttribute("sortedList", sortedList);
        
        return "/sub/sub3-3";  // JSP 페이지 이름
    }
    
    @GetMapping("/calculateCalories")
    public String calculateCalories(
            @RequestParam(value = "weight", defaultValue = "65") double weight, // 기본값 65kg
            @RequestParam(value = "time", defaultValue = "1") double timeInHours, // 기본값 1시간
            Model model) {
        
    	double calories = calorieService.calculateCalories(weight, timeInHours);
    	System.out.println("칼로리 : "+calories);
        model.addAttribute("calories", calories);
        return "/index"; // 결과를 보여줄 view 이름 (JSP 혹은 Thymeleaf)
    }
}
     

  
   
