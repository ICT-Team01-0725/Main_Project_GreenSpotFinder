package com.ict.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ict.edu.dao.searchTreeDAO;
import com.ict.edu.vo.searchTreeVO;


@Service
public class searchTreeServiceImpl implements searchTreeService {

	@Autowired
	private searchTreeDAO searchTreeDAO;
	
	@Override
	public List<searchTreeVO> getSearchTree() {
		return searchTreeDAO.getSearchTree();
	}

	@Override
	public List<searchTreeVO> getSearchBar(String treename) {
		 
		return searchTreeDAO.getSearchBar(treename);
	}

	
	// select 값
	@Override
	public List<searchTreeVO> getSortedTrees(String category) {
		
	     switch (category) {
         case "address":
             return searchTreeDAO.getSortedByAddress();  // 주소순 정렬
         case "date":
             return searchTreeDAO.getSortedByDate();  // 지정일순 정렬
         case "age":
             return searchTreeDAO.getSortedByAge();   // 수령순 정렬
     }
		return null;
		
		
	}

    


	

}
