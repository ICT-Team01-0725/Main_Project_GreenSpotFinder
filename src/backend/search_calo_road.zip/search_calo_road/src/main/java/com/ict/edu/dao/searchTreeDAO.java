package com.ict.edu.dao;

import java.util.List;

import com.ict.edu.vo.searchTreeVO;

public interface searchTreeDAO {

	public List<searchTreeVO> getSearchTree();

	public List<searchTreeVO> getSearchBar(String treename);

	public List<searchTreeVO> getSortedTrees(String category);

	public List<searchTreeVO> getSortedByAddress();

	public List<searchTreeVO> getSortedByDate();

	public List<searchTreeVO> getSortedByAge();

}
