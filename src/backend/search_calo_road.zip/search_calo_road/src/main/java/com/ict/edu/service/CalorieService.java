package com.ict.edu.service;

import org.springframework.stereotype.Service;

@Service
public class CalorieService {
	private static final double MET_WALKING = 4.3;

	public double calculateCalories(double weight, double timeInHours) {
		return weight * timeInHours * MET_WALKING;
	}
}