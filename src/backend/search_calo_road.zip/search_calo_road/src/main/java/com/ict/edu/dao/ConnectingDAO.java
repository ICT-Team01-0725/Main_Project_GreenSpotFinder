package com.ict.edu.dao;

import java.util.List;

import com.ict.edu.vo.ConnectionVO;

public interface ConnectingDAO {
	
	  // 기본 공원 리스트 조회
    public List<ConnectionVO> getConnectionPark();

    // 공원명으로 검색
    public List<ConnectionVO> getSearchPark(String searchPark);
}