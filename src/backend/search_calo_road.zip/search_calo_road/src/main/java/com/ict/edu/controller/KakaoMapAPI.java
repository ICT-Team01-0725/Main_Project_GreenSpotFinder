package com.ict.edu.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KakaoMapAPI {

    // 카카오 API 키
    private static final String API_KEY = "7c79589a716fc6110f83c9c147e34ec8";
 
    @RequestMapping("/kakaomap")
    @ResponseBody
    public String kakaoMap2() {
        // 예시: 출발지와 목적지의 위도, 경도
        double startLat = 37.5665; // 서울
        double startLng = 126.9780; // 서울
        double endLat = 37.5775;   // 서울 근처
        double endLng = 126.9850;  // 서울 근처

        try {
            // API 호출 URL 생성
            String urlStr = String.format(
            	//	"https://apis-navi.kakaomobility.com/v1/directions?origin=127.11015314141542,37.39472714688412&destination=127.10824367964793,37.401937080111644"
            		"https://apis-navi.kakaomobility.com/v1/directions?origin=" +startLng + "," + startLat  + "&destination=" + endLng + "," + endLat
            );

            // URL 객체 생성
            URL url = new URL(urlStr);

            // HttpURLConnection 객체 생성
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setRequestProperty("Authorization", "KakaoAK 7c79589a716fc6110f83c9c147e34ec8");
            connection.setRequestProperty("Content-type", "application/json");
            
            // 응답 코드 확인
            int responseCode = connection.getResponseCode();
            System.out.println("responseCode " + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 성공적으로 응답 받았을 경우
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // 응답 데이터 출력 (경로 정보)
                String jsonResponse = response.toString();
                System.out.println("API Response: " + jsonResponse); // 응답 데이터 확인

				
                JsonObject jsonResponseObj = JsonParser.parseString(jsonResponse).getAsJsonObject(); // String을 parseString 메서드에 전달
                JsonArray routes = jsonResponseObj.getAsJsonArray("routes");
                // 첫 번째 경로 정보 가져오기
                JsonObject route = routes.get(0).getAsJsonObject();
                JsonArray sections = route.getAsJsonArray("sections");

                // 첫 번째 섹션 가져오기
                JsonObject section = sections.get(0).getAsJsonObject();
                JsonArray roads = section.getAsJsonArray("roads");

                // 첫 번째 도로 정보 가져오기
                JsonObject road = roads.get(0).getAsJsonObject();
                JsonArray vertexes = road.getAsJsonArray("vertexes");

                // 경로 좌표 출력
                for (int i = 0; i < vertexes.size(); i += 2) {
                    double lng = vertexes.get(i).getAsDouble(); // 경도
                    double lat = vertexes.get(i + 1).getAsDouble(); // 위도
                    System.out.println("경로 좌표: " + lat + ", " + lng);
                }
				 

            } else {
                System.out.println("GET 요청 실패, 응답 코드: " + responseCode);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
		return null;
    }
}
