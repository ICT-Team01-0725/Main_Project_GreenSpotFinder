package com.ict.edu.service;

import java.util.List;

import com.ict.edu.vo.ConnectionVO;
import com.ict.edu.vo.searchTreeVO;

public interface searchTreeService {

	public List<searchTreeVO> getSearchTree();
	
	 public List<searchTreeVO> getSearchBar(String treename);

	 public List<searchTreeVO> getSortedTrees(String category);
	
}
