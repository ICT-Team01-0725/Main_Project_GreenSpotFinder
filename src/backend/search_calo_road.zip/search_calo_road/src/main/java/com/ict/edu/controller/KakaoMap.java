package com.ict.edu.controller;

public class KakaoMap {

}
