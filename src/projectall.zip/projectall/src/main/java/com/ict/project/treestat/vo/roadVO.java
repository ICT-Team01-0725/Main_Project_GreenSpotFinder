package com.ict.project.treestat.vo;


public class roadVO {

	private String r_idx, 
			r_na, 
			r_s_lat, 
			r_s_lon, 
			r_e_lat, 
			r_e_lon, 
			r_ty, 
			r_vol,
			r_ye, 
			r_sto, 
			r_rna, 
			r_rty, 
			r_rsec,
			r_pho, 
			r_ce_na,
			r_dat, 
			r_ce_co,
			r_ce_ad;
	        
	private double r_len;
	        
	


	public String getR_idx() {
		return r_idx;
	}

	public void setR_idx(String r_idx) {
		this.r_idx = r_idx;
	}

	public String getR_na() {
		return r_na;
	}

	public void setR_na(String r_na) {
		this.r_na = r_na;
	}

	public String getR_s_lat() {
		return r_s_lat;
	}

	public void setR_s_lat(String r_s_lat) {
		this.r_s_lat = r_s_lat;
	}

	public String getR_s_lon() {
		return r_s_lon;
	}

	public void setR_s_lon(String r_s_lon) {
		this.r_s_lon = r_s_lon;
	}

	public String getR_e_lat() {
		return r_e_lat;
	}

	public void setR_e_lat(String r_e_lat) {
		this.r_e_lat = r_e_lat;
	}

	public String getR_e_lon() {
		return r_e_lon;
	}

	public void setR_e_lon(String r_e_lon) {
		this.r_e_lon = r_e_lon;
	}

	public String getR_ty() {
		return r_ty;
	}

	public void setR_ty(String r_ty) {
		this.r_ty = r_ty;
	}

	public String getR_vol() {
		return r_vol;
	}

	public void setR_vol(String r_vol) {
		this.r_vol = r_vol;
	}


	public double getR_len() {
		return r_len;
	}

	public void setR_len(double r_len) {
		this.r_len = r_len;
	}

	public String getR_ye() {
		return r_ye;
	}

	public void setR_ye(String r_ye) {
		this.r_ye = r_ye;
	}

	public String getR_sto() {
		return r_sto;
	}

	public void setR_sto(String r_sto) {
		this.r_sto = r_sto;
	}

	public String getR_rna() {
		return r_rna;
	}

	public void setR_rna(String r_rna) {
		this.r_rna = r_rna;
	}

	public String getR_rty() {
		return r_rty;
	}

	public void setR_rty(String r_rty) {
		this.r_rty = r_rty;
	}

	public String getR_rsec() {
		return r_rsec;
	}

	public void setR_rsec(String r_rsec) {
		this.r_rsec = r_rsec;
	}

	public String getR_pho() {
		return r_pho;
	}

	public void setR_pho(String r_pho) {
		this.r_pho = r_pho;
	}

	public String getR_ce_na() {
		return r_ce_na;
	}

	public void setR_ce_na(String r_ce_na) {
		this.r_ce_na = r_ce_na;
	}

	public String getR_dat() {
		return r_dat;
	}

	public void setR_dat(String r_dat) {
		this.r_dat = r_dat;
	}

	public String getR_ce_co() {
		return r_ce_co;
	}

	public void setR_ce_co(String r_ce_co) {
		this.r_ce_co = r_ce_co;
	}

	public String getR_ce_ad() {
		return r_ce_ad;
	}

	public void setR_ce_ad(String r_ce_ad) {
		this.r_ce_ad = r_ce_ad;
	}

}
