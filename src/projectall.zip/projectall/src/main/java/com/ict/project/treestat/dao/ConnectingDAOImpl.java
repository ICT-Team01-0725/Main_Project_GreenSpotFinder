package com.ict.project.treestat.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.project.treestat.vo.ConnectionVO;


@Repository
public class ConnectingDAOImpl implements ConnectingDAO {

	@Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    // 기본 공원 리스트 조회
    @Override
    public List<ConnectionVO> getConnectionPark() {
        return sqlSessionTemplate.selectList("connectionpark.list");  // 쿼리 호출
    }

    // 공원명으로 검색
    @Override
    public List<ConnectionVO> getSearchPark(String searchPark) {
        return sqlSessionTemplate.selectList("connectionpark.name", searchPark);  // 쿼리 호출
    }
}