package com.ict.project.treestat.vo;

public class searchTreeVO {

	public String t_area_idx, t_ce_na, t_num, t_sdate, t_ty, t_fna, t_bna, t_tty, t_age, t_fr, t_gr, t_gr_num, t_rad, t_ad;

	public String getT_area_idx() {
		return t_area_idx;
	}

	public void setT_area_idx(String t_area_idx) {
		this.t_area_idx = t_area_idx;
	}

	public String getT_ce_na() {
		return t_ce_na;
	}

	public void setT_ce_na(String t_ce_na) {
		this.t_ce_na = t_ce_na;
	}

	public String getT_num() {
		return t_num;
	}

	public void setT_num(String t_num) {
		this.t_num = t_num;
	}

	public String getT_sdate() {
		return t_sdate;
	}

	public void setT_sdate(String t_sdate) {
		this.t_sdate = t_sdate;
	}

	public String getT_ty() {
		return t_ty;
	}

	public void setT_ty(String t_ty) {
		this.t_ty = t_ty;
	}

	public String getT_fna() {
		return t_fna;
	}

	public void setT_fna(String t_fna) {
		this.t_fna = t_fna;
	}

	public String getT_bna() {
		return t_bna;
	}

	public void setT_bna(String t_bna) {
		this.t_bna = t_bna;
	}

	public String getT_tty() {
		return t_tty;
	}

	public void setT_tty(String t_tty) {
		this.t_tty = t_tty;
	}

	public String getT_age() {
		return t_age;
	}

	public void setT_age(String t_age) {
		this.t_age = t_age;
	}



	public String getT_fr() {
		return t_fr;
	}

	public void setT_fr(String t_fr) {
		this.t_fr = t_fr;
	}

	public String getT_gr() {
		return t_gr;
	}

	public void setT_gr(String t_gr) {
		this.t_gr = t_gr;
	}

	public String getT_gr_num() {
		return t_gr_num;
	}

	public void setT_gr_num(String t_gr_num) {
		this.t_gr_num = t_gr_num;
	}

	public String getT_rad() {
		return t_rad;
	}

	public void setT_rad(String t_rad) {
		this.t_rad = t_rad;
	}

	public String getT_ad() {
		return t_ad;
	}

	public void setT_ad(String t_ad) {
		this.t_ad = t_ad;
	}


}
