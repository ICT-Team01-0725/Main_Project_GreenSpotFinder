package com.ict.project.treestat.dao;

import java.util.List;

import com.ict.project.treestat.vo.searchTreeVO;


public interface searchTreeDAO {
	
	public int getCountTree();

	public List<searchTreeVO> getSearchTree(int offset, int limit);

	public List<searchTreeVO> getSearchBar(String treename);

	public List<searchTreeVO> getSortedTrees(String category);

	public List<searchTreeVO> getSortedByAddress();

	public List<searchTreeVO> getSortedByDate();

	public List<searchTreeVO> getSortedByAge();

}
