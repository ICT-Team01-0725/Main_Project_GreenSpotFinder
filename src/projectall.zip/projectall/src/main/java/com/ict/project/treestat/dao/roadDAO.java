package com.ict.project.treestat.dao;

import java.util.List;

import com.ict.project.treestat.vo.roadVO;


public interface roadDAO {


	List<roadVO> roadSearchByAddress(String searchKeyword);
}
