package com.ict.project.treestat.service;

import java.util.List;

import com.ict.project.treestat.vo.ConnectionVO;


public interface ConnectingService {

	 // 기본 공원 리스트 조회 (첫 화면에 나오는 리스트 4개)
    public List<ConnectionVO> getConnectionPark();

    // 공원명으로 검색
    public List<ConnectionVO> getSearchPark(String searchPark);
}