package com.ict.project.inquery.vo;

public class InqueryVO {
	
	// 게시판마다 변수명 확인해서 작성하기
	private String i_idx, u_id, i_tle, i_con, i_dat, i_ans, a_idx, i_acon;

	public String getI_idx() {
		return i_idx;
	}

	public void setI_idx(String i_idx) {
		this.i_idx = i_idx;
	}

	public String getU_idx() {
		return u_id;
	}

	public void setU_idx(String u_id) {
		this.u_id = u_id;
	}

	public String getI_tle() {
		return i_tle;
	}

	public void setI_tle(String i_tle) {
		this.i_tle = i_tle;
	}

	public String getI_con() {
		return i_con;
	}

	public void setI_con(String i_con) {
		this.i_con = i_con;
	}

	public String getI_dat() {
		return i_dat;
	}

	public void setI_dat(String i_dat) {
		this.i_dat = i_dat;
	}

	public String getI_ans() {
		return i_ans;
	}

	public void setI_ans(String i_ans) {
		this.i_ans = i_ans;
	}

	public String getA_idx() {
		return a_idx;
	}

	public void setA_idx(String a_idx) {
		this.a_idx = a_idx;
	}

	public String getI_acon() {
		return i_acon;
	}

	public void setI_acon(String i_acon) {
		this.i_acon = i_acon;
	}
	
	
	// 변수 다 작성후엔 getter/setter 생성 
}
	