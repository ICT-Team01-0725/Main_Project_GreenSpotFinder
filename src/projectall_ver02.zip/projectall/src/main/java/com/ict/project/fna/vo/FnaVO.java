package com.ict.project.fna.vo;

public class FnaVO {
	
	// 게시판마다 변수명 확인해서 작성하기
	private String f_idx, a_idx, f_tle, f_fcon, f_acon, f_dat, f_up;

	public String getF_idx() {
		return f_idx;
	}

	public void setF_idx(String f_idx) {
		this.f_idx = f_idx;
	}

	public String getA_idx() {
		return a_idx;
	}

	public void setA_idx(String a_idx) {
		this.a_idx = a_idx;
	}

	public String getF_tle() {
		return f_tle;
	}

	public void setF_tle(String f_tle) {
		this.f_tle = f_tle;
	}

	public String getF_fcon() {
		return f_fcon;
	}

	public void setF_fcon(String f_fcon) {
		this.f_fcon = f_fcon;
	}

	public String getF_acon() {
		return f_acon;
	}

	public void setF_acon(String f_acon) {
		this.f_acon = f_acon;
	}

	public String getF_dat() {
		return f_dat;
	}

	public void setF_dat(String f_dat) {
		this.f_dat = f_dat;
	}

	public String getF_up() {
		return f_up;
	}

	public void setF_up(String f_up) {
		this.f_up = f_up;
	} 
	
	
	// 변수 다 작성후엔 getter/setter 생성 
}
	