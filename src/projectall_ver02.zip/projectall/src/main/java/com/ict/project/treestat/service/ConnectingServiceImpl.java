package com.ict.project.treestat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ict.project.treestat.dao.ConnectingDAO;
import com.ict.project.treestat.vo.ConnectionVO;




@Service
public class ConnectingServiceImpl implements ConnectingService {

    @Autowired
    private ConnectingDAO connectingDAO;

    // 기본 공원 리스트 조회
    @Override
    public List<ConnectionVO> getConnectionPark() {
    	return connectingDAO.getConnectionPark();  // DAO 호출
    }

    // 공원명으로 검색
    @Override
    public List<ConnectionVO> getSearchPark(String searchPark) {
        return connectingDAO.getSearchPark(searchPark);  // DAO 호출
    }
}