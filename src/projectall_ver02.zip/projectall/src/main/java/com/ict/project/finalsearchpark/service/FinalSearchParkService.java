package com.ict.project.finalsearchpark.service;

import java.util.List;

import com.ict.project.finalsearchpark.vo.FinalSearchParkVO;



public interface FinalSearchParkService {
    // 주소로 공원 검색
    List<FinalSearchParkVO> searchParkByAddress(String p_ad);

    // 지역별 공원 검색
    List<FinalSearchParkVO> searchParkByRegion(String region);
}