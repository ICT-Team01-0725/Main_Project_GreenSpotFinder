package com.ict.project.admin.vo;

public class AdminVO {
	
	private String a_idx, a_id, a_pw, a_na, a_pho, a_em, a_stat, a_log;

	public String getA_idx() {
		return a_idx;
	}

	public void setA_idx(String a_idx) {
		this.a_idx = a_idx;
	}

	public String getA_id() {
		return a_id;
	}

	public void setA_id(String a_id) {
		this.a_id = a_id;
	}

	public String getA_pw() {
		return a_pw;
	}

	public void setA_pw(String a_pw) {
		this.a_pw = a_pw;
	}

	public String getA_na() {
		return a_na;
	}

	public void setA_na(String a_na) {
		this.a_na = a_na;
	}

	public String getA_pho() {
		return a_pho;
	}

	public void setA_pho(String a_pho) {
		this.a_pho = a_pho;
	}

	public String getA_em() {
		return a_em;
	}

	public void setA_em(String a_em) {
		this.a_em = a_em;
	}

	public String getA_stat() {
		return a_stat;
	}

	public void setA_stat(String a_stat) {
		this.a_stat = a_stat;
	}

	public String getA_log() {
		return a_log;
	}

	public void setA_log(String a_log) {
		this.a_log = a_log;
	}
	
}
